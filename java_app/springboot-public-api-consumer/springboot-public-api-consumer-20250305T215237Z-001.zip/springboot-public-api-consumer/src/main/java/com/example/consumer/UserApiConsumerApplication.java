package com.example.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserApiConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserApiConsumerApplication.class, args);
	}

}
